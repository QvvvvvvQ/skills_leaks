const NoiseOverlay = () => {
  return <div className="noise-overlay" aria-hidden="true" />;
};

export default NoiseOverlay;
